#pragma once

namespace menu
{
	extern bool open;

	void render();
}