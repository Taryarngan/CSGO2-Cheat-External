#pragma once

#include "../atgui.h"

namespace Skins
{
	void RenderTab();
}