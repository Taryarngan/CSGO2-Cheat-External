#pragma once

#include "../atgui.h"

namespace PlayerList
{
	extern bool showWindow;

	extern void RenderWindow();
}